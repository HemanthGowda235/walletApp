package com.wallet.WalletProject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wallet.WalletProject.Entity.Account;

public interface AccountRepository extends JpaRepository<Account, Integer> {

	
}
