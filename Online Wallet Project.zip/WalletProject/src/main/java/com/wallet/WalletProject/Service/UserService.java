package com.wallet.WalletProject.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.wallet.WalletProject.Entity.Role;
import com.wallet.WalletProject.Entity.User;
import com.wallet.WalletProject.Repository.RoleRepository;
import com.wallet.WalletProject.Repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository repo;
	
	@Autowired
	private WebSecurityConfig webConfig;
	
	@Autowired
	private RoleRepository roleRepository;
	
	
	
	public List<User> listAll()
	{
		return repo.findAll();
	}
	
	public void save(User user)
	{
		String encryptedPassword = webConfig.passwordEncoder().encode(user.getPassword());
		user.setPassword(encryptedPassword);
		Role role = roleRepository.findByName("USER");
		user.addRole(role);
		repo.save(user);
	}
	
	public void saveEdit(User user)
	{
		Role role = roleRepository.findByName("USER");
		user.addRole(role);
		repo.save(user);
	}
	

	public User get(Integer id)
	{
		return repo.findById(id).get();
	}
	
	public void delete(Integer id)
	{
		User user = repo.findById(id).get();
		Role role = new Role(1);
		user.removeRole(role);
		
		repo.deleteById(id);
		
	}
	
	
	public User getCurrentUser() 
	{
		final Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
			String username = auth.getName();
			
			User loggedInuser= repo.getUserByUsername(username);
			
			return loggedInuser;
	}

}
