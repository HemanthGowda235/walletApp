package com.wallet.WalletProject.Service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.wallet.WalletProject.Entity.Wallet;
import com.wallet.WalletProject.Repository.WalletRepository;

@Service
public class WalletService {
	
	@Autowired
	WalletRepository repo;

	@Transactional
	public Wallet createWallet() {
		Wallet wallet = null;
		int x = 0;
		//int y = 1;
		wallet = repo.createWallet(x);
		//Integer id = wallet.getWalletId();
//		if(wallet != null)
//		{
//			repo.updateStatus(y, id);
//		}
	
		return wallet;
	}
//	@Transactional
//	public void updateStatus(Integer id)
//	{
//		
//		int y = 1;
//		 repo.updateStatus(y, id);
//		
//		
//		
//	}
	public Wallet get(Integer id)
	{
		
		return repo.findById(id).get();
		
	}

	public void save(Wallet wallet)
	{
		
		repo.save(wallet);
	}

	public void delete(Integer id)
	{
		repo.deleteById(id);
	}
}
