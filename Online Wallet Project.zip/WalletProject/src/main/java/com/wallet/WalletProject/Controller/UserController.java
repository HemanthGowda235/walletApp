package com.wallet.WalletProject.Controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.wallet.WalletProject.Entity.FromToDate;
import com.wallet.WalletProject.Entity.Transaction;
import com.wallet.WalletProject.Entity.User;
import com.wallet.WalletProject.Entity.UserExcelExporter;
import com.wallet.WalletProject.Entity.Wallet;
import com.wallet.WalletProject.Service.TransactionService;
import com.wallet.WalletProject.Service.UserService;
import com.wallet.WalletProject.Service.WalletService;

@Controller
public class UserController {

	@Autowired
	private UserService service;

	@Autowired
	private WalletService walser;
	
	@Autowired
	private TransactionService transactionService;
	
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		List<User> listUsers = service.listAll();
		model.addAttribute("listUsers", listUsers);

		return "index";
	}

	@RequestMapping("/new")
	public String showNewUserForm(Model model) {
		User user = new User();

		model.addAttribute("user", user);

		return "new_user";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute("user") User user) {
		Wallet wallet = null;
		wallet = walser.createWallet();
		
		user.setWallet(wallet);
	
		wallet.setWalletBalance(0);
		wallet.setStatus(1);
		
		service.save(user);
		return "redirect:/new?success";
	}
	
	@RequestMapping(value = "/saveedit", method = RequestMethod.POST)
	public String saveEditUser(@ModelAttribute("user") User user)
	{
		Integer i = user.getId();
	Wallet wallet = walser.get(i);
//	System.out.println("Wallet while editing : "+wallet);

				user.setWallet(wallet);
				
		service.saveEdit(user);
//		System.out.println("User after editing : "+user);
		return "redirect:/";
	}

	@RequestMapping("/edit/{id}")
	public ModelAndView showEditUserForm(@PathVariable(name = "id") Integer id) {
		ModelAndView mav = new ModelAndView("edit_user");

		User user = service.get(id);
		mav.addObject("user", user);

		return mav;
	}

	@RequestMapping("/delete/{id}")
	public String deleteUser(@PathVariable(name = "id") Integer id) 
	{
		service.delete(id);

		return "redirect:/";
	}

	@GetMapping("/wallet/{id}")
	public String showWallet(@PathVariable(name = "id") Integer id, Model model) {
		User currentUser = service.getCurrentUser();
		System.out.println(currentUser);

		int uId = currentUser.getId();
		User user = service.get(uId);

		Wallet wallet = walser.get(id);

		wallet.setUser(currentUser);
		user.setWallet(wallet);

		Integer i = wallet.getWalletBalance();
		model.addAttribute("walletBalance", i);
		System.out.println("Wallet Balance of current user= "+i);
		System.out.println("Current User Wallet Id : " + wallet.getWalletId());
		return "wallet";
	}

	@GetMapping("/addmoney/{id}")
	public ModelAndView showAddMoney(@ModelAttribute("wallet") Wallet wallet) {
		ModelAndView view = new ModelAndView();

		view.addObject("wallet", new Wallet());
		view.setViewName("addmoney");
		return view;
	}

	@PostMapping("/saveamount/{id}")
	public String addMoney(@ModelAttribute("wallet") Wallet wallet, @PathVariable(name = "id") Integer id)

	{
		Integer a = wallet.getWalletBalance();
		User currentUser = service.getCurrentUser();
		// System.out.println(currentUser);

		int uId = currentUser.getId();
		User user = service.get(uId);

		Wallet walletCUser = walser.get(id);
		walletCUser.setUser(currentUser);
		user.setWallet(walletCUser);
		System.out.println(walletCUser.getWalletId());
		Integer i = walletCUser.getWalletBalance();

		walletCUser.setWalletBalance(a + i);

		Integer b = walletCUser.getWalletBalance();

		System.out.println("Wallet Balance is : " + b);
		Integer wId = walletCUser.getWalletId();
		Transaction t = new Transaction();
		t.setFromWallet(wId);
		t.setToWallet(wId);
		t.setAmount(a);
		t.setCredit("credited");
		t.setDebit("-");
		
		LocalDate currentTime = LocalDate.now();
		
		t.setTransactionDate(currentTime);
		transactionService.saveTransaction(t);
		
		walser.save(walletCUser);
		return "redirect:/addmoney/{id}?success";
	}

	@GetMapping("/withdrawmoney/{id}")
	public ModelAndView showWithdrawMoney(@ModelAttribute("wallet") Wallet wallet) {
		ModelAndView view = new ModelAndView();
		view.addObject("wallet", new Wallet());
		view.setViewName("withdrawmoney");
		return view;
	}

	@PostMapping("/withdrawamount/{id}")
	public String withdrawMoney(@ModelAttribute("wallet") Wallet wallet, @PathVariable(name = "id") Integer id)

	{
		Integer a = wallet.getWalletBalance();
		User currentUser = service.getCurrentUser();

		int uId = currentUser.getId();
		User user = service.get(uId);

		Wallet walletCUser = walser.get(id);
		walletCUser.setUser(currentUser);
		user.setWallet(walletCUser);
		System.out.println(walletCUser.getWalletId());
		Integer wId = walletCUser.getWalletId();
		Integer i = walletCUser.getWalletBalance();

		walletCUser.setWalletBalance(i - a);

		Integer b = walletCUser.getWalletBalance();

		System.out.println("Wallet Balance is : " + b);
		
		Transaction t = new Transaction();
		t.setFromWallet(wId);
		t.setToWallet(wId);
		t.setAmount(a);
		t.setDebit("debitted");
		t.setCredit("-");
		
		LocalDate currentTime = LocalDate.now();
		
		t.setTransactionDate(currentTime);
		transactionService.saveTransaction(t);
		
		walser.save(walletCUser);
		return "redirect:/withdrawmoney/{id}?success";
	}

	@GetMapping("/sendmoney")
	public ModelAndView showSendMoney(@ModelAttribute("wallet") Wallet wallet) {
		ModelAndView view = new ModelAndView();

		view.addObject("wallet", new Wallet());
		view.setViewName("sendmoney");
		return view;
	}

	@PostMapping("/sendamount")
	public String sendMoney(@ModelAttribute("wallet") Wallet wallet)
	{
		Integer i = wallet.getWalletId();
		Integer a = wallet.getWalletBalance();
		
		User user = service.get(i);
		Wallet walletUser = walser.get(i);
		walletUser.setUser(user);
		user.setWallet(walletUser);
		
		Integer b = walletUser.getWalletBalance();
		
		walletUser.setWalletBalance(b+a);
		
		
		System.out.println("Wallet Balance of reciever= "+walletUser.getWalletBalance());
		
		User currentUser = service.getCurrentUser();
		int uId = currentUser.getId();
		User userC = service.get(uId);
		Wallet walletC = walser.get(uId);
		
		walletC.setUser(userC);
		userC.setWallet(walletC);
		
		Integer c = walletC.getWalletBalance();
		walletC.setWalletBalance(c - a);
		
		Transaction t = new Transaction();
		t.setFromWallet(uId);
		t.setToWallet(i);
		t.setAmount(a);
		t.setDebit("debitted");
		t.setCredit("-");
		LocalDate currentTime = LocalDate.now();
		t.setTransactionDate(currentTime);
		transactionService.saveTransaction(t);
		
		Transaction t1 = new Transaction();
		t1.setFromWallet(uId);
		t1.setToWallet(i);
		t1.setAmount(a);
		t1.setDebit("-");
		t1.setCredit("credited");
		LocalDate currentTime1 = LocalDate.now();
		t1.setTransactionDate(currentTime1);
		transactionService.saveTransaction(t1);
		
		System.out.println("Wallet Balance of sender= "+walletC.getWalletBalance());
		walser.save(walletC);
		return "redirect:/sendmoney?success";
		
	}
	@RequestMapping("/transaction/{id}")
	public String viewTransactionHistrory(@PathVariable(name = "id") Integer id, Model model)
	{
		User user = service.get(id);
		int walletId = user.getWallet().getWalletId();
		List<Transaction> listTransactions = transactionService.listAllTransactions(walletId) ;
		model.addAttribute("listTransactions", listTransactions);
		return "transaction";
		
	}
	
	@GetMapping("/datewisetransactions")
	public ModelAndView datewiseTransactions()
	{
		ModelAndView mav = new ModelAndView();
		mav.addObject("date",new FromToDate());
		mav.setViewName("datewisetransactions");
		return mav;
	}
	
	@GetMapping("/transactions/export")
	public void exportToExcel(HttpServletResponse response, @ModelAttribute("date") FromToDate date) throws IOException
	{
		String from =date.getFromDate();
		String to = date.getToDate();
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate fromDate = null;
		LocalDate toDate = null;
		try {
		
		fromDate = LocalDate.parse(from, formatter);
			
			
		toDate = LocalDate.parse(to, formatter);
			
			
		} catch (DateTimeParseException e) {
			
			e.printStackTrace();
		}
		
		System.out.println(fromDate);
		System.out.println(toDate);
			
		
		
		response.setContentType("application/octet-stream");
		String headerKey = "Content-Disposition";
		
		String headerValue = "attachment; filename=transactions.xlsx";
		
		response.setHeader(headerKey, headerValue);
		
		Integer id = service.getCurrentUser().getId();
		
		List<Transaction> transactions = transactionService.listAllTransactions(id,fromDate,toDate);
		System.out.println(transactions.toString());
		UserExcelExporter excelExporter = new UserExcelExporter(transactions);
		excelExporter.export(response);
	}
}
