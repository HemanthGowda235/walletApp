package com.wallet.WalletProject.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wallet.WalletProject.Entity.Account;
import com.wallet.WalletProject.Repository.AccountRepository;

@Service
public class AccountService {

	@Autowired
	private AccountRepository repo;
	
	
	public void save(Account account)
	{
		repo.save(account);
	}
	
//	public void deposit(int amount)
//	{
//	account.setCredit(amount);
//	Integer	balance = account.getBalance()+amount;
//	account.setBalance(balance);	
//	
//	}
}
